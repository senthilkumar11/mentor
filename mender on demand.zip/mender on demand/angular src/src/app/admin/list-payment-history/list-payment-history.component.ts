import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-payment-history',
  templateUrl: './list-payment-history.component.html',
  styleUrls: ['./list-payment-history.component.css']
})
export class ListPaymentHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
