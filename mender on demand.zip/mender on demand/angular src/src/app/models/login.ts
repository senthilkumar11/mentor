export class Login
{
    id:number;
    userName:string;
    password:string;
    userType:string;
    constructor()
    {

    }
}