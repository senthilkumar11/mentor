package com.mod.menter.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mod.menter.dao.LoginDao;
import com.mod.menter.model.Login;

@Service
public class AdminServiceImpl implements AdminService{

	
}
