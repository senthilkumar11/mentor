package com.mod.menter.service;

import com.mod.menter.model.Login;

public interface AdminService {


}
