package com.mod.menter.controller;



public class AdminController {

}