package com.mod.menter.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mod.menter.model.Admin;

public interface AdminDao extends JpaRepository<Admin, Integer>{

}
